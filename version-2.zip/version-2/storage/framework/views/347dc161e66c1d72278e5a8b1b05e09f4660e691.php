<html lang="en">
<head>
    <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <!-- Nav  -->
    <?php echo $__env->make('includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- #menu  -->
    <div class="md:grid md:grid-cols-5">
        <!-- Nav link  -->
        <?php echo $__env->make('includes.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Stats -->
        <div id="statsDiv" class="col-span-4 ml-2">
            <div class="text-2xl bg-white text-center border-b shadow py-2">
                <?php echo $__env->make('layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="">
                <div class="bg-white mx-2 p-3">
                    <div class="flex justify-end">
                        <a href="<?php echo e(route('weeklyletter.index')); ?>">
                            <button class="create-btn">
                                <svg class="w-7 h-7" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clip-rule="evenodd"></path></svg> 
                                All Weekly Letter
                            </button>
                        </a>
                    </div>
                    <div>
                        <?php if($weeklyletter->count()): ?>
                            <div class="shadow-lg p-4 lg:w-3/4 lg:mx-auto">
                                <div class="my-6 mx-3 text-3xl font-medium">
                                    <?php echo e($weeklyletter->title); ?> <br>
                                    <span class="font-normal text-lg">By <?php echo e($weeklyletter->author->name); ?></span><br>
                                    <span class="font-normal text-sm"><?php echo e($weeklyletter->status); ?></span>
                                </div>
                                <div class="md:my-auto text-lg">
                                    <?php echo html_entity_decode($weeklyletter->content); ?> <br>
                                </div>
                                <div class="my-3 mx-3">
                                    <form action="<?php echo e(route('weeklyletter.send')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="px-6 py-4 flex justify-end">
                                            <input style="display:none;" type="text" name="letter_id" value="<?php echo e($weeklyletter->id); ?>">
                                            <button type="submit" class="btn-submit tracking-wider">Send to Subscribers</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="bg-white text-2xl text-center py-2">
                                No Weekly Letter Found
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('js/dashboard.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\piccolo\teampiccolo\version-2\resources\views/dashboard/weeklyletter/show.blade.php ENDPATH**/ ?>