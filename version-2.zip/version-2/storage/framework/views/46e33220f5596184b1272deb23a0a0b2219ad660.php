

<?php $__env->startSection('header'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <?php echo html_entity_decode($content); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.email', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\piccolo\teampiccolo\version-2\resources\views/emails/sendweeklyletter.blade.php ENDPATH**/ ?>