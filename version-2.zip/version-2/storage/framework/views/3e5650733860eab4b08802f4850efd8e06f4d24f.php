

<?php $__env->startSection('page-meta'); ?>
    <meta name="description" content="<?php echo e($course->description); ?>">
    <meta name="keywords" content="HTML, CSS, JavaScript, Bootstrap, Enroll, Computer Essentials, Web Development, Mobile Applicaation, Entrepreneur,Information Technology, Kano, Training">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
    <?php echo e($course->name); ?> | Team Piccolo Global Enterprises
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-content'); ?>
    <!-- Show Course -->
    <div id="statsDiv" class="ml-2">
        <div class="text-2xl bg-white text-center border-b shadow py-2">
            <?php echo $__env->make('layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="w-full lg:w-4/5 mx-auto shadow-lg py-4">
            <div class="bg-white mx-2 p-3">
                <div class="flex justify-end pt-14">
                    <a href="<?php echo e(url()->previous()); ?>">
                        <button class="create-btn">
                        <svg class="w-7 h-7" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M8.445 14.832A1 1 0 0010 14v-2.798l5.445 3.63A1 1 0 0017 14V6a1 1 0 00-1.555-.832L10 8.798V6a1 1 0 00-1.555-.832l-6 4a1 1 0 000 1.664l6 4z"></path></svg>
                            Back
                        </button>
                    </a>
                </div>
                <div>
                    <?php if($course->count()): ?>
                    <div class="my-6 mx-3 text-3xl font-medium">
                        <?php echo e($course->name); ?>

                    </div>
                    <div class="grid grid-cols-2 md:gap-4 mx-2 my-6 border-b-2 border-green-600 py-4">
                        <div class="md:my-auto text-lg">
                            <?php echo e($course->description); ?> <br>
                            <span class="font-medium">
                                <?php if($course->video->count() > 1): ?>
                                    <?php echo e($course->video->count()); ?> Videos
                                <?php else: ?>
                                    <?php echo e($course->video->count()); ?> Video
                                <?php endif; ?>
                            </span>
                        </div>
                        <div class="flex justify-end">
                            <img class="w-32 h-32 md:w-48 md:h-48" src=" <?php echo e($course->photo); ?>" alt=" <?php echo e($course->name); ?> logo">
                        </div>
                        
                    </div>
                    <div class="md:grid md:grid-cols-3 md:gap-4 mx-2 my-6">
                        <?php $__currentLoopData = $course->video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card">
                                <div>
                                    <img class="w-full p-2 mx-auto border-2" src=" <?php echo e($video->photo); ?> " alt="<?php echo e($video->name); ?> Image">    
                                </div>
                                <div class="font-medium text-xl py-1 border-b mb-4">
                                    <?php echo e($video->name); ?>

                                </div>
                                <div class="flex justify-center border-t pt-4 pb-2 items-center">
                                    <form action="<?php echo e(route('play.video', $video->id)); ?>">
                                        <button class="play-btn">
                                            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clip-rule="evenodd"></path></svg>
                                            &nbsp;&nbsp;
                                            <span> Play</span>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php else: ?>
                        <div class="bg-white text-2xl text-center py-2">
                            No Course Found
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\piccolo\teampiccolo\version-2\resources\views/courses/show-course.blade.php ENDPATH**/ ?>