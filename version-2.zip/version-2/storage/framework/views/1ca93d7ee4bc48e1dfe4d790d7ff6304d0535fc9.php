

<?php $__env->startSection('page-meta'); ?>
<meta name="description" content="Want to learn about Programming? Visit our blog to get the latest talks on programming.">
<meta name="keywords" content="Writer, Blog, Entrepreneur, Information Technology, Kano, Training">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
    Blog | Team Piccolo Global Enterprises
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-content'); ?>
    <!-- Blog  -->
    <?php if($blogs->count()): ?>
        <div class="page-title">
            Team Piccolo Blog 
        </div>
        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('blog.read', $blog->id)); ?>">
                <div class="shadow p-10 m-4 hover:shadow-lg md:mx-auto md:w-1/3">
                    <img class="h-42 my-4 mx-auto" src="<?php echo e($blog->photo); ?>" alt="<?php echo e($blog->title); ?>">
                    <h3 class="paragraph-title"><?php echo e($blog->title); ?></h3>
                    <p class="paragraph">
                        <?php echo html_entity_decode(Str::limit($blog->content, 150, '...')); ?><br>
                        <div class="flex my-4 items-center justify-between">
                            <div class="flex items-center">
                                <img class="w-10 h-10" src="<?php echo e(\App\Models\Admin::where(['id' => $blog->author])->first()->photo ?? asset('/images/logo.png')); ?>" alt="<?php echo e(\App\Models\Admin::where(['id' => $blog->author])->first()->name); ?>"> 
                                &nbsp;&nbsp;
                                <span><?php echo e(\App\Models\Admin::where(['id' => $blog->author])->first()->name); ?></span>
                            </div>
                            <div>
                                <?php echo e($blog->created_at->diffForhumans()); ?>

                            </div>
                        </div>
                        <span>Read: <?php echo e($blog->views); ?></span>
                    </p>
                </div>
            </a>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="text-2xl lg:mx-32 px-4 my-6 relative top-10 my-24">
            No Blog Post found!
        </div>
    <?php endif; ?>
    <div class="my-6 mx-3">
        <?php echo e($blogs->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\piccolo\teampiccolo\version-2\resources\views/blog.blade.php ENDPATH**/ ?>