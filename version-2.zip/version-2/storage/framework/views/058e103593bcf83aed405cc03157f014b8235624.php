

<?php $__env->startSection('page-meta'); ?>
<meta name="description" content="<?php echo html_entity_decode($blog->content); ?>">
<meta name="keywords" content="About, Piccolo, Team, Enroll, Computer Essentials, Web Development, Mobile Applicaation, Entrepreneur,Information Technology, Kano, Training">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
    <?php echo e($blog->title); ?> | Team Piccolo Global Enterprises
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<div class="relative z-0 w-full">
    <div class="w-full lg:w-2/3 mx-auto leading-snug items-center">
        <div class="px-8 py-24 shadow">
            <div>
                <img class="mx-auto h-32" src="<?php echo e($blog->photo); ?>" alt="<?php echo e($blog->title); ?>">
            </div>
            <div class="text-3xl mb-8">
                <span class="border-b-2 border-green-600"><?php echo e($blog->title); ?></span>
            </div>
            <p class="paragraph">
                <?php echo html_entity_decode($blog->content); ?>

            </p>
            <p class="my-6">
                <div class="flex my-4 items-center justify-between">
                    <div class="flex items-center">
                        <img class="w-10 h-10" src="<?php echo e(\App\Models\Admin::where(['id' => $blog->author])->first()->photo ?? asset('/images/logo.png')); ?>" alt="<?php echo e(\App\Models\Admin::where(['id' => $blog->author])->first()->name); ?>"> 
                        &nbsp;&nbsp;
                        <span><?php echo e(\App\Models\Admin::where(['id' => $blog->author])->first()->name); ?></span>
                    </div>
                    <div>
                        <?php echo e($blog->created_at->diffForhumans()); ?>

                    </div>
                </div>
                <span>View: <?php echo e($blog->views); ?></span>
            </p>
            <p>
                <div class="flex justify-end">
                    <a href="<?php echo e(url()->previous()); ?>">
                        <button class="create-btn" style="width:120%; height:120%;">
                            <img class="w-6 text-white" src="<?php echo e(asset('images/back-arrow.png')); ?>" alt="">
                            &nbsp;&nbsp;
                            Back
                        </button>
                    </a>
                </div>
            </p>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\piccolo\teampiccolo\version-2\resources\views/readBlog.blade.php ENDPATH**/ ?>