<?php if(count($errors) > 0): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="py-2 px-4 text-center text-lg">
            <?php echo e($error); ?>

			<hr>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="text-green-500 py-2 px-4 text-center text-lg">
        <h4><?php echo e(session('success')); ?></h4>
		<hr>
    </div>
<?php endif; ?>


<?php if(session('error')): ?>
    <div class="py-2 px-4 text-center text-lg">
        <h4><?php echo e(session('error')); ?></h4>
		<hr>
    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\piccolo\teampiccolo\version-2\resources\views/layouts/messages.blade.php ENDPATH**/ ?>