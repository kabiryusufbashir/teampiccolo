

<?php $__env->startSection('page-meta'); ?>
<meta name="description" content="Want to learn about Programming? Visit our blog to get the latest talks on programming.">
<meta name="keywords" content="Writer, Blog, Entrepreneur, Information Technology, Kano, Training">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
    Page Not Page | Team Piccolo Global Enterprises
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-content'); ?>
    <!-- error  -->
    <div class="text-center text-green-600 text-3xl pt-24 pb-6 md:p-10 md:m-4 md:mx-auto md:w-1/3">
        <img class="w-48 mx-auto my-4" src="<?php echo e(asset('images/404.png')); ?>" alt="404 page">
        Oops... Page not found 
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\piccolo\teampiccolo\version-2\resources\views/errors/404.blade.php ENDPATH**/ ?>