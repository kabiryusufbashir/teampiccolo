

<?php $__env->startSection('page-meta'); ?>
<meta name="description" content="Enroll to our Academy to have access to our free courses on Computer Essentials, Web Development and Mobile Application">
<meta name="keywords" content="Enroll, Computer Essentials, Web Development, Mobile Applicaation, Entrepreneur,Information Technology, Kano, Training">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
    Contact | Team Piccolo Global Enterprises
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<div class="py-8">
    <div class="grid grid-cols-1 lg:grid lg:grid-cols-2 gap-8 lg:mx-32 px-4 py-6 pt-24">
        <div class="shadow-lg p-6">
            <span class="border-b-4 border-green-600 text-2xl">For Any Enquiries</span>
            <form action="<?php echo e(route('contact')); ?>" method="POST" class="mt-4">
                <?php echo csrf_field(); ?>
                <div>
                    <input required type="text" name="name" value="<?php echo e(old('name')); ?>" placeholder="Full Name" class="input-box <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <input required type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email Address" class="input-box <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <input required type="text" name="phone" value="<?php echo e(old('phone')); ?>" placeholder="Phone No (e.g 08000000000)" class="input-box <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <textarea required name="enquiry" class="px-5 w-full border border-gray-400 h-24 rounded-lg my-2 text-lg focus:outline-none <?php $__errorArgs = ['enquiry'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enquiry"> </textarea>
                    <?php $__errorArgs = ['enquiry'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="text-center mt-6">
                    <button class="btn-submit">Submit</button>
                </div>
            </form>
        </div>
        <div>
            <div>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1380.029350253521!2d8.604651825840886!3d11.952856080372493!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x11ae8265683aac83%3A0xd477b851b4bad822!2sIbrahim%20Kunya%20Housing%20Estate!5e0!3m2!1sen!2sng!4v1569176345363!5m2!1sen!2sng" width="100%" height="350" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
            </div>
            <div class="py-4">
                <div class="py-1 text-green-600">
                    <i class="fas fa-phone text-green-600"></i> 
                    <span>
                        <a class="" href="tel:+2348068593127">
                            08068593127
                        </a>
                        ,
                        <a class="text-green-600" href="tel:+2348032338280">
                            08032338280
                        </a>
                    </span>
                </div>
                <div class="py-1">
                    <i class="fas fa-envelope-square text-green-600"></i>
                    <span>
                        <a class="text-green-600" href="mailto:info@teampiccolo.com">
                           info@teampiccolo.com
                        </a>
                    </span>
                </div>
                <div class="py-1">
                    <a>
                        <i class="fas fa-home text-green-600"></i> 
                        <a href="#" class="text-green-600">No 7 Kabiru Alhaji Bashir Street off Maiduguri Road Kano State, Nigeria</a>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\piccolo\teampiccolo\version-2\resources\views/contact.blade.php ENDPATH**/ ?>