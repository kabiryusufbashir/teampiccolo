

<?php $__env->startSection('page-meta'); ?>
<meta name="description" content="login to access your courses on our Academy">
<meta name="keywords" content="Enroll, Computer Essentials, Web Development, Mobile Applicaation, Entrepreneur, Information Technology, Kano, Training">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-title'); ?>
    Change Password | Team Piccolo Global Enterprises
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<div class="relative z-0 w-full h-screen">
    <div class="w-full flex justify-between leading-snug items-center h-screen">
        <div class="border-t-2 w-full lg:w-1/3 px-6 lg:px-8 py-8 mx-auto shadow-lg">
            <img class="w-32 h-32 mx-auto" src="<?php echo e(asset('images/sign-in.png')); ?>" alt="Sign In">
            <form action="<?php echo e(route('confirm.change.password')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div>
                    <input type="hidden" name="phone_number" value="<?php echo e(session('phone_number')); ?>">
                    <span class="input-title">New Password</span>
                    <input required type="password" name="password" placeholder="New Password" class="input-box <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <span class="input-title">Confirm Password</span>
                    <input required type="password" name="password_confirmation" placeholder="Confirm Password" class="input-box <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="text-center mt-6">
                    <button class="btn-submit">Change Password</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\piccolo\teampiccolo\version-2\resources\views/auth/changepassword.blade.php ENDPATH**/ ?>