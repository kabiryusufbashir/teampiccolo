<span class="border-b-2 border-green-600"><a id="file" href="<?php echo e($ebook->path); ?>"><?php echo e($ebook->name); ?></a></span>   
<script>
    const viewFile = document.querySelector('#file');
    window.onload = function(){
        viewFile.click();
    }
</script><?php /**PATH C:\xampp\htdocs\piccolo\teampiccolo\version-2\resources\views/ebookDownload.blade.php ENDPATH**/ ?>