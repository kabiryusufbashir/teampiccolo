

<?php $__env->startSection('page-title'); ?>
    Verify Number | Team Piccolo Global Enterprises
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<div class="relative z-0 w-full h-screen">
    <div class="w-full flex justify-between leading-snug items-center h-screen">
        <div class="border-t-2 w-full lg:w-1/3 text-center px-6 lg:px-14 py-8 mx-auto shadow-lg">
            <img class="w-32 h-32 mx-auto mb-2 rounded-full" src="<?php echo e(asset('images/verify.jpg')); ?>" alt="Verify Number">
            <div class="text-center px-8 my-auto">
                <div class="mb-2">
                    Please enter the OTP sent to your number: <?php echo e(session('phone_number')); ?>

                </div> 
                <form class="text-left" action="<?php echo e(route('confirm-no')); ?> " method="POST">
                    <?php echo csrf_field(); ?>
                    <div>
                        <div>
                            <input type="hidden" name="phone_number" value="<?php echo e(session('phone_number')); ?>">
                            <input placeholder="Please enter the OTP sent to your number" id="verification_code" type="tel" class="input-box <?php $__errorArgs = ['verification_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="verification_code" value="<?php echo e(old('verification_code')); ?>" required>
                            <?php $__errorArgs = ['verification_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="text-center mt-6">
                        <button type="submit" class="btn-submit">
                            <?php echo e(__('Verify Phone Number')); ?>

                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\piccolo\teampiccolo\version-2\resources\views/auth/confirm_no.blade.php ENDPATH**/ ?>