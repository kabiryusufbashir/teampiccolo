@extends('layouts.email')

@section('header')
    Thanks for subscribing to our newsletter!
@endsection

@section('body')
    You recently requested an email subscription to Team Piccolo Newsletter. <br>
    We can't wait to send you our weekly newsletter!
@endsection
