<html lang="en">
<head>
    @include('includes.head')
</head>
<body>
    <!-- Nav  -->
    @include('includes.nav')

    <!-- Menu  -->
    <div class="md:grid md:grid-cols-5">
        <!-- Nav link  -->
        @include('includes.menu')
        <!-- Stats -->
        <div id="statsDiv" class="col-span-4 ml-2">
            <div class="text-2xl bg-white text-center border-b shadow py-2">
                @include('layouts.messages')
            </div>
            <div class="md:grid md:grid-cols-4 md:gap-4">
                <div class="col-span-4 bg-white p-3">
                    <div class="flex justify-end">
                        <a href="{{ route('record.index') }}">
                            <button class="create-btn">
                                <svg class="w-7 h-7" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clip-rule="evenodd"></path></svg> 
                                All Record
                            </button>
                        </a>
                    </div>
                    <div class="lg:w-3/4 mx-auto">
                        <form class="bg-white shadow-lg p-4" action="{{ route('record.store') }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            <div>
                                <h2 class="text-2xl text-center py-4 font-medium border-b-4 uppercase">Add Record</h2>
                            </div>
                            <div class="my-2">
                                <input style="display:none;" type="text" name="admin_id" value="{{ auth()->user()->id }}">
                                <span class="input-title">Transaction Type</span>
                                <select name="transaction_type" value="{{old('transaction_type')}}" class="input-box @error('transaction_type') border-red-500 @enderror">
                                    <option value=""></option>
                                    <option value="Debit">Debit</option>
                                    <option value="Credit">Credit</option>
                                </select>
                                @error('transaction_type')
                                    {{$message}}
                                @enderror
                            </div>
                            <div class="my-2">
                                <span class="input-title">Amount</span>
                                <input type="text" name="amount" value="{{old('amount')}}" placeholder="Amount" class="input-box @error('amount') border-red-500 @enderror">
                                @error('amount')
                                    {{$message}}
                                @enderror
                            </div>
                            <div class="my-2">
                                <span class="input-title">Transaction Details</span>
                                <textarea id="content" name="transaction_details" class="px-5 w-full border border-gray-400 h-24 rounded-lg my-2 text-lg focus:outline-none @error('transaction_details') border-red-500 @enderror" placeholder="Transaction Details">{{old('transaction_details')}}</textarea>
                                @error('transaction_details')
                                    {{$message}}
                                @enderror
                            </div>
                            <div class="my-2">
                                <span class="input-title">Transaction Date</span>
                                <input type="datetime-local" name="date_of_transaction" value="{{old('date_of_transaction')}}" placeholder="Transaction Date" class="input-box @error('transaction_date') border-red-500 @enderror">
                                @error('date_of_transaction')
                                    {{$message}}
                                @enderror
                            </div>
                            <div class="px-6 py-4 flex justify-end">
                                <button type="submit" class="btn-submit tracking-wider">Add Record</button>
                            </div>
                        </form>
                    </div>    
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.ckeditor.com/ckeditor5/23.0.0/classic/ckeditor.js"></script>
    <script>
        ClassicEditor
            .create(document.querySelector('#content'))
            .catch( error => {
                console.error( error );
            } );
    </script>
    <script src="{{ asset('js/dashboard.js') }}"></script>
</body>
</html>